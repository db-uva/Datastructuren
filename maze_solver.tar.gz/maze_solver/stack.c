#include <stdio.h>
#include <stdlib.h>

#include "stack.h"

struct stack {
    /* ... SOME CODE MISSING HERE ... */
};

struct stack *stack_init(size_t capacity) {
    /* ... SOME CODE MISSING HERE ... */
}

void stack_cleanup(struct stack *s) {
    /* ... SOME CODE MISSING HERE ... */
}

void stack_stats(const struct stack *s) {
    /* ... SOME CODE MISSING HERE ... */
}

int stack_push(struct stack *s, int c) {
    /* ... SOME CODE MISSING HERE ... */
}

int stack_pop(struct stack *s) {
    /* ... SOME CODE MISSING HERE ... */
}

int stack_peek(const struct stack *s) {
    /* ... SOME CODE MISSING HERE ... */
}

int stack_empty(const struct stack *s) {
    /* ... SOME CODE MISSING HERE ... */
}

size_t stack_size(const struct stack *s) {
    /* ... SOME CODE MISSING HERE ... */
}
